import { useState } from 'react';
import { Dashboard } from './components/Dashboard';
import { ClassroomList } from './components/ClassroomList';
import { ClassroomDetail } from './components/ClassroomDetail';
import { LayoutDashboard, School, Calendar, Bell, Settings, Menu, X } from 'lucide-react';

export interface Student {
  id: string;
  name: string;
  email: string;
  avatar: string;
  enrollmentDate: string;
  attendance: number;
  averageGrade: number;
}

export interface Comment {
  id: string;
  studentName: string;
  studentAvatar: string;
  content: string;
  timestamp: string;
  replies: Comment[];
}

export interface Material {
  id: string;
  type: 'file' | 'image' | 'video' | 'link';
  title: string;
  url: string;
  thumbnail?: string;
  uploadedAt: string;
}

export interface Topic {
  id: string;
  title: string;
  description: string;
  materials: Material[];
  comments: Comment[];
  createdAt: string;
}

export interface Assignment {
  id: string;
  title: string;
  description: string;
  dueDate: string;
  maxScore: number;
  submissions: {
    studentId: string;
    submittedAt?: string;
    score?: number;
    status: 'pending' | 'submitted' | 'graded';
  }[];
}

export interface Classroom {
  id: string;
  name: string;
  subject: string;
  color: string;
  students: Student[];
  topics: Topic[];
  assignments: Assignment[];
  schedule: {
    day: string;
    time: string;
  }[];
}

function App() {
  const [currentView, setCurrentView] = useState<'dashboard' | 'classrooms' | 'calendar' | 'notifications'>('dashboard');
  const [selectedClassroom, setSelectedClassroom] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const [classrooms, setClassrooms] = useState<Classroom[]>([
    {
      id: '1',
      name: 'Matemáticas Avanzadas',
      subject: 'Matemáticas',
      color: '#3B82F6',
      schedule: [
        { day: 'Lunes', time: '08:00 - 10:00' },
        { day: 'Miércoles', time: '08:00 - 10:00' },
      ],
      students: [
        {
          id: 's1',
          name: 'Ana García',
          email: 'ana@example.com',
          avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
          enrollmentDate: '2024-09-01',
          attendance: 95,
          averageGrade: 88,
        },
        {
          id: 's2',
          name: 'Carlos Ruiz',
          email: 'carlos@example.com',
          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
          enrollmentDate: '2024-09-01',
          attendance: 92,
          averageGrade: 85,
        },
        {
          id: 's3',
          name: 'María López',
          email: 'maria@example.com',
          avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
          enrollmentDate: '2024-09-01',
          attendance: 98,
          averageGrade: 92,
        },
      ],
      topics: [
        {
          id: 't1',
          title: 'Cálculo Diferencial',
          description: 'Introducción a los conceptos fundamentales del cálculo diferencial',
          createdAt: '2024-11-01',
          materials: [
            {
              id: 'm1',
              type: 'file',
              title: 'Guía de Derivadas.pdf',
              url: '#',
              uploadedAt: '2024-11-01',
            },
            {
              id: 'm2',
              type: 'video',
              title: 'Clase 1: Límites',
              url: '#',
              thumbnail: 'https://images.unsplash.com/photo-1509228627152-72ae9ae6848d?w=400&h=225&fit=crop',
              uploadedAt: '2024-11-02',
            },
          ],
          comments: [
            {
              id: 'c1',
              studentName: 'Ana García',
              studentAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
              content: '¿Podría explicar más sobre la regla de la cadena?',
              timestamp: '2024-11-15T10:30:00',
              replies: [],
            },
          ],
        },
        {
          id: 't2',
          title: 'Integrales',
          description: 'Métodos de integración y aplicaciones',
          createdAt: '2024-11-15',
          materials: [],
          comments: [],
        },
      ],
      assignments: [
        {
          id: 'a1',
          title: 'Ejercicios de Derivadas',
          description: 'Resolver los problemas 1-20 del capítulo 3',
          dueDate: '2024-12-20',
          maxScore: 100,
          submissions: [
            { studentId: 's1', submittedAt: '2024-12-10', score: 88, status: 'graded' },
            { studentId: 's2', submittedAt: '2024-12-12', score: 85, status: 'graded' },
            { studentId: 's3', status: 'pending' },
          ],
        },
      ],
    },
    {
      id: '2',
      name: 'Historia Universal',
      subject: 'Historia',
      color: '#10B981',
      schedule: [
        { day: 'Martes', time: '10:00 - 12:00' },
        { day: 'Jueves', time: '10:00 - 12:00' },
      ],
      students: [
        {
          id: 's4',
          name: 'Pedro Sánchez',
          email: 'pedro@example.com',
          avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
          enrollmentDate: '2024-09-01',
          attendance: 90,
          averageGrade: 78,
        },
      ],
      topics: [],
      assignments: [],
    },
  ]);

  const handleSelectClassroom = (classroomId: string) => {
    setSelectedClassroom(classroomId);
    setCurrentView('classrooms');
  };

  const handleBackToClassrooms = () => {
    setSelectedClassroom(null);
  };

  const handleAddClassroom = (classroom: Omit<Classroom, 'id'>) => {
    const newClassroom: Classroom = {
      ...classroom,
      id: Date.now().toString(),
    };
    setClassrooms([...classrooms, newClassroom]);
  };

  const handleUpdateClassroom = (classroomId: string, updates: Partial<Classroom>) => {
    setClassrooms(classrooms.map(c => c.id === classroomId ? { ...c, ...updates } : c));
  };

  const handleDeleteClassroom = (classroomId: string) => {
    setClassrooms(classrooms.filter(c => c.id !== classroomId));
    if (selectedClassroom === classroomId) {
      setSelectedClassroom(null);
    }
  };

  const selectedClassroomData = classrooms.find(c => c.id === selectedClassroom);

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-64' : 'w-20'} bg-white border-r border-gray-200 transition-all duration-300 flex flex-col`}>
        <div className="p-6 flex items-center justify-between border-b border-gray-200">
          {sidebarOpen && <h1 className="text-blue-600">EduManage</h1>}
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 hover:bg-gray-100 rounded-lg"
          >
            {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          <button
            onClick={() => {
              setCurrentView('dashboard');
              setSelectedClassroom(null);
            }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
              currentView === 'dashboard' && !selectedClassroom
                ? 'bg-blue-50 text-blue-600'
                : 'text-gray-700 hover:bg-gray-100'
            }`}
          >
            <LayoutDashboard className="w-5 h-5" />
            {sidebarOpen && <span>Dashboard</span>}
          </button>

          <button
            onClick={() => {
              setCurrentView('classrooms');
              setSelectedClassroom(null);
            }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
              currentView === 'classrooms' && !selectedClassroom
                ? 'bg-blue-50 text-blue-600'
                : 'text-gray-700 hover:bg-gray-100'
            }`}
          >
            <School className="w-5 h-5" />
            {sidebarOpen && <span>Mis Aulas</span>}
          </button>

          <button
            onClick={() => setCurrentView('calendar')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
              currentView === 'calendar'
                ? 'bg-blue-50 text-blue-600'
                : 'text-gray-700 hover:bg-gray-100'
            }`}
          >
            <Calendar className="w-5 h-5" />
            {sidebarOpen && <span>Calendario</span>}
          </button>

          <button
            onClick={() => setCurrentView('notifications')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
              currentView === 'notifications'
                ? 'bg-blue-50 text-blue-600'
                : 'text-gray-700 hover:bg-gray-100'
            }`}
          >
            <Bell className="w-5 h-5" />
            {sidebarOpen && <span>Notificaciones</span>}
          </button>
        </nav>

        <div className="p-4 border-t border-gray-200">
          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-gray-700 hover:bg-gray-100">
            <Settings className="w-5 h-5" />
            {sidebarOpen && <span>Configuración</span>}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        {selectedClassroomData ? (
          <ClassroomDetail
            classroom={selectedClassroomData}
            onBack={handleBackToClassrooms}
            onUpdate={(updates) => handleUpdateClassroom(selectedClassroomData.id, updates)}
          />
        ) : currentView === 'dashboard' ? (
          <Dashboard classrooms={classrooms} onSelectClassroom={handleSelectClassroom} />
        ) : currentView === 'classrooms' ? (
          <ClassroomList
            classrooms={classrooms}
            onSelectClassroom={handleSelectClassroom}
            onAddClassroom={handleAddClassroom}
            onDeleteClassroom={handleDeleteClassroom}
          />
        ) : currentView === 'calendar' ? (
          <div className="p-8">
            <h2 className="mb-6">Calendario de Clases</h2>
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="grid grid-cols-7 gap-4">
                {['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'].map(day => (
                  <div key={day} className="text-center text-gray-600">
                    {day}
                  </div>
                ))}
                {Array.from({ length: 35 }, (_, i) => {
                  const dayClasses = classrooms.flatMap(c =>
                    c.schedule.filter(s => {
                      const dayMap: { [key: string]: number } = {
                        'Lunes': 0, 'Martes': 1, 'Miércoles': 2, 'Jueves': 3, 'Viernes': 4, 'Sábado': 5, 'Domingo': 6
                      };
                      return dayMap[s.day] === i % 7;
                    }).map(s => ({ ...s, classroom: c }))
                  );
                  
                  return (
                    <div key={i} className="aspect-square border border-gray-200 rounded-lg p-2 hover:bg-gray-50">
                      <div className="text-gray-400 text-sm">{i + 1}</div>
                      <div className="mt-1 space-y-1">
                        {dayClasses.map((dc, idx) => (
                          <div
                            key={idx}
                            className="text-xs p-1 rounded truncate"
                            style={{ backgroundColor: dc.classroom.color + '20', color: dc.classroom.color }}
                          >
                            {dc.classroom.name}
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        ) : (
          <div className="p-8">
            <h2 className="mb-6">Notificaciones</h2>
            <div className="space-y-4">
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <Bell className="w-5 h-5 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <p className="text-gray-700">Nueva pregunta en <strong>Matemáticas Avanzadas</strong></p>
                    <p className="text-gray-500 text-sm mt-1">Ana García comentó en "Cálculo Diferencial"</p>
                    <p className="text-gray-400 text-xs mt-2">Hace 2 horas</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                    <Bell className="w-5 h-5 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <p className="text-gray-700">Nueva entrega de tarea</p>
                    <p className="text-gray-500 text-sm mt-1">Carlos Ruiz entregó "Ejercicios de Derivadas"</p>
                    <p className="text-gray-400 text-xs mt-2">Hace 5 horas</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;
