import { useState } from 'react';
import { Classroom } from '../App';
import { Plus, BookOpen, Users, MoreVertical, Trash2 } from 'lucide-react';

interface ClassroomListProps {
  classrooms: Classroom[];
  onSelectClassroom: (classroomId: string) => void;
  onAddClassroom: (classroom: Omit<Classroom, 'id'>) => void;
  onDeleteClassroom: (classroomId: string) => void;
}

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'];

export function ClassroomList({ classrooms, onSelectClassroom, onAddClassroom, onDeleteClassroom }: ClassroomListProps) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newClassroom, setNewClassroom] = useState({
    name: '',
    subject: '',
    color: COLORS[0],
  });
  const [activeMenu, setActiveMenu] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddClassroom({
      ...newClassroom,
      students: [],
      topics: [],
      assignments: [],
      schedule: [],
    });
    setNewClassroom({ name: '', subject: '', color: COLORS[0] });
    setShowAddModal(false);
  };

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-gray-900 mb-2">Mis Aulas</h1>
          <p className="text-gray-600">Gestiona todas tus aulas y cursos</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Plus className="w-5 h-5" />
          Nueva Aula
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {classrooms.map(classroom => (
          <div
            key={classroom.id}
            className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow"
          >
            <div
              className="h-32 p-6 flex items-center justify-center"
              style={{ backgroundColor: classroom.color }}
            >
              <BookOpen className="w-16 h-16 text-white opacity-80" />
            </div>
            
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1 min-w-0">
                  <h3 className="text-gray-900 mb-1 truncate">{classroom.name}</h3>
                  <p className="text-sm text-gray-600">{classroom.subject}</p>
                </div>
                <div className="relative">
                  <button
                    onClick={() => setActiveMenu(activeMenu === classroom.id ? null : classroom.id)}
                    className="p-2 hover:bg-gray-100 rounded-lg"
                  >
                    <MoreVertical className="w-5 h-5 text-gray-600" />
                  </button>
                  {activeMenu === classroom.id && (
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 z-10">
                      <button
                        onClick={() => {
                          onDeleteClassroom(classroom.id);
                          setActiveMenu(null);
                        }}
                        className="w-full flex items-center gap-2 px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg"
                      >
                        <Trash2 className="w-4 h-4" />
                        Eliminar Aula
                      </button>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-4 mb-4 text-sm text-gray-600">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  <span>{classroom.students.length} estudiantes</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="p-3 bg-gray-50 rounded-lg">
                  <p className="text-gray-900">{classroom.topics.length}</p>
                  <p className="text-xs text-gray-600">Temas</p>
                </div>
                <div className="p-3 bg-gray-50 rounded-lg">
                  <p className="text-gray-900">{classroom.assignments.length}</p>
                  <p className="text-xs text-gray-600">Tareas</p>
                </div>
              </div>

              <button
                onClick={() => onSelectClassroom(classroom.id)}
                className="w-full px-4 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800"
              >
                Ver Aula
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add Classroom Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h2 className="text-gray-900 mb-4">Crear Nueva Aula</h2>
            
            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Nombre del Aula
                  </label>
                  <input
                    type="text"
                    value={newClassroom.name}
                    onChange={(e) => setNewClassroom({ ...newClassroom, name: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="ej. Matemáticas Avanzadas"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Materia
                  </label>
                  <input
                    type="text"
                    value={newClassroom.subject}
                    onChange={(e) => setNewClassroom({ ...newClassroom, subject: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="ej. Matemáticas"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Color
                  </label>
                  <div className="flex gap-2">
                    {COLORS.map(color => (
                      <button
                        key={color}
                        type="button"
                        onClick={() => setNewClassroom({ ...newClassroom, color })}
                        className={`w-10 h-10 rounded-lg ${
                          newClassroom.color === color ? 'ring-2 ring-offset-2 ring-gray-900' : ''
                        }`}
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Crear Aula
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
