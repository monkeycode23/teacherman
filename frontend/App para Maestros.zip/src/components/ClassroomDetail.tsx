import { useState } from 'react';
import { Classroom } from '../App';
import { ArrowLeft, Users, BookOpen, ClipboardList, BarChart3 } from 'lucide-react';
import { TopicsTab } from './TopicsTab';
import { StudentsTab } from './StudentsTab';
import { AssignmentsTab } from './AssignmentsTab';
import { AnalyticsTab } from './AnalyticsTab';

interface ClassroomDetailProps {
  classroom: Classroom;
  onBack: () => void;
  onUpdate: (updates: Partial<Classroom>) => void;
}

type Tab = 'topics' | 'students' | 'assignments' | 'analytics';

export function ClassroomDetail({ classroom, onBack, onUpdate }: ClassroomDetailProps) {
  const [activeTab, setActiveTab] = useState<Tab>('topics');

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div
        className="p-8 text-white"
        style={{ backgroundColor: classroom.color }}
      >
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-white hover:text-gray-100 mb-6"
        >
          <ArrowLeft className="w-5 h-5" />
          Volver a Mis Aulas
        </button>

        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-white mb-2">{classroom.name}</h1>
            <p className="text-white opacity-90">{classroom.subject}</p>
          </div>
          <div className="flex gap-4 text-white">
            <div className="text-right">
              <p className="opacity-90">Estudiantes</p>
              <p>{classroom.students.length}</p>
            </div>
            <div className="text-right">
              <p className="opacity-90">Temas</p>
              <p>{classroom.topics.length}</p>
            </div>
            <div className="text-right">
              <p className="opacity-90">Tareas</p>
              <p>{classroom.assignments.length}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200 bg-white">
        <div className="px-8 flex gap-6">
          <button
            onClick={() => setActiveTab('topics')}
            className={`flex items-center gap-2 px-4 py-4 border-b-2 transition-colors ${
              activeTab === 'topics'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            <BookOpen className="w-5 h-5" />
            Temario
          </button>

          <button
            onClick={() => setActiveTab('students')}
            className={`flex items-center gap-2 px-4 py-4 border-b-2 transition-colors ${
              activeTab === 'students'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            <Users className="w-5 h-5" />
            Estudiantes
          </button>

          <button
            onClick={() => setActiveTab('assignments')}
            className={`flex items-center gap-2 px-4 py-4 border-b-2 transition-colors ${
              activeTab === 'assignments'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            <ClipboardList className="w-5 h-5" />
            Tareas
          </button>

          <button
            onClick={() => setActiveTab('analytics')}
            className={`flex items-center gap-2 px-4 py-4 border-b-2 transition-colors ${
              activeTab === 'analytics'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            <BarChart3 className="w-5 h-5" />
            Estadísticas
          </button>
        </div>
      </div>

      {/* Tab Content */}
      <div className="p-8">
        {activeTab === 'topics' && (
          <TopicsTab
            topics={classroom.topics}
            onUpdateTopics={(topics) => onUpdate({ topics })}
          />
        )}
        
        {activeTab === 'students' && (
          <StudentsTab
            students={classroom.students}
            onUpdateStudents={(students) => onUpdate({ students })}
          />
        )}
        
        {activeTab === 'assignments' && (
          <AssignmentsTab
            assignments={classroom.assignments}
            students={classroom.students}
            onUpdateAssignments={(assignments) => onUpdate({ assignments })}
          />
        )}
        
        {activeTab === 'analytics' && (
          <AnalyticsTab classroom={classroom} />
        )}
      </div>
    </div>
  );
}
